/* global gapi */
import React, { useState } from "react";
import { Row, Col, Spin } from "antd";
import styled from "styled-components";
//import "../App.css";
//import { gapi } from "gapi-script";
// import { google } from "googleapis";
import { gapi } from "gapi-script";
import GoogleDriveImage from "../assets/images/google.png";

import { style } from "./styles";

const NewDocumentWrapper = styled.div`
  ${style}
`;
var CLIENT_ID =
  "236717214097-jmdc31nh8d2h5mim0it1gbdvrja94cg2.apps.googleusercontent.com";
var API_KEY = "AIzaSyARbVgWR0mkXN7Ntozoumstt2SNzLcCdqE";
const DISCOVERY_DOCS = [
  "https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest",
  "https://admin.googleapis.com/$discovery/rest?version=directory_v1",
];
const scopes = 
"https://www.googleapis.com/auth/admin.directory.group.readonly https://www.googleapis.com/auth/admin.directory.group.member.readonly https://www.googleapis.com/auth/calendar.readonly https://www.googleapis.com/auth/admin.directory.user.readonly";
;

//var scopes = "profile";
const SelectSource = () => {
  const [signedInUser, setSignedInUser] = useState();
  const [isLoadingGoogleDriveApi, setIsLoadingGoogleDriveApi] = useState(false);
  async function getAllUsersInOrg() {
    let page = "";
    let pageToken = "";
    let staffList = [];

    do {
      page = await gapi.client.directory.users.list({
        customer: "my_customer",
        projection: "full",
        orderBy: "givenName",
        sortOrder: "descending",
        maxResults: 100,
        pageToken: pageToken,
      });

      staffList = staffList.concat(page.result.users);

      pageToken = page.nextPageToken;
    } while (pageToken);

    return staffList;
  }
  function getUserOrgWPItem(user){
 
    if(user.hasOwnProperty('phones')){
      const primaryOrg = user.phones.filter((x) => x.type === "work")[0].value
 
      return primaryOrg;
    }else{
      return "";
    }
  }
  function getUserOrgMBItem(user){
 
    if(user.hasOwnProperty('phones')){
      const primaryOrg = user.phones.filter((x) => x.type === "mobile")[0].value
 
      return primaryOrg;
    }else{
      return "";
    }
  }
  function getUserOrgMGItem(user){
 
    if(user.hasOwnProperty('relations')){
      const primaryOrg = user.relations.filter((x) => x.type === "manager")[0].value
 
      return primaryOrg;
    }else{
      return "";
    }
  }
  function getUserOrgEIDItem(user){
 
    if(user.hasOwnProperty('externalIds')){
      const primaryOrg = user.externalIds.filter((x) => x.type === "organization")[0].value
 
      return primaryOrg;
    }else{
      return "";
    }
  }
  function getUserOrgLOCItem(user){
 
    if(user.hasOwnProperty('locations')){
      var bid=user.locations[0].hasOwnProperty("buildingId")? user.locations[0].buildingId: "";
      var floorname=user.locations[0].hasOwnProperty("floorName")? user.locations[0].floorName: "";
      var floorsection=user.locations[0].hasOwnProperty("floorSection")? user.locations[0].floorSection: "";
      return (bid + " "+ floorname + " " + floorsection);
    }else{
      return "";
    }
  }
  

  
  const updateSigninStatus = (isSignedIn) => {
    if (isSignedIn) {
      // Set the signed in user
      //setSignedInUser(gapi.auth2.getAuthInstance().currentUser.je.Qt);
      setIsLoadingGoogleDriveApi(false);
      // list files if user is authenticated
      listFiles();
    } else {
      // prompt user to sign in
      handleAuthClick();
    }
  };
  const listFiles = () => {
    gapi.client.load("admin", "directory_v1", () => {});
    getAllUsersInOrg().then((data) => {
      console.log(data);
     
      let staffMember = data.map((user) => {
        var arr123 = [];
        if(user.hasOwnProperty("customSchemas"))
        {
          const cfield = user.customSchemas;
        
       
        Object.keys(cfield).map((key) => {
          var exchangefld = cfield[key];

         
          
          
          arr123.push(exchangefld);
          return [key];
        });
      
        console.log(arr123);
   
        }
        return {
         ...arr123,
          'firstName': user.name.givenName,
          'lastName': user.name.familyName,
          'email': user.primaryEmail,
          'job': user.hasOwnProperty("organizations")
            ? user.organizations[0].hasOwnProperty("title")
              ? user.organizations[0].title
              : ""
            : "",
          'department': user.hasOwnProperty("organizations")
            ? user.organizations[0].hasOwnProperty("department")
              ? user.organizations[0].department
              : ""
            : "",
            'employeetype':user.hasOwnProperty("organizations")
            ? user.organizations[0].hasOwnProperty("description")
              ? user.organizations[0].description
              : ""
            : "",
            'workphone': getUserOrgWPItem(user),
            'mobile': getUserOrgMBItem(user),
            'manager':getUserOrgMGItem(user),
            'employeeid':getUserOrgEIDItem(user),
            'location':getUserOrgLOCItem(user),
            'image':user.hasOwnProperty("thumbnailPhotoUrl")? user.thumbnailPhotoUrl: ""
        };
      });
      console.log(staffMember);
    });
    // const res1 = await gapi.client.directory.groups.list({
    //   customer: "my_customer",
    // });
    // console.log(res1.result.groups);

    // const res1x = await gapi.client.directory.users.list({
    //   customer: "my_customer",
    //   //viewType:'domain_public',
    //   //query: "orgUnitPath='/'",
    //   // query:'orgTitle=Developer',
    //   //query:'MyCustomField.CF2=parjinder',
    //   //query: "MyCustomField.CF4>1987-08-05",

    //   projection: "full",
    //   orderBy: "givenName",
    //   sortOrder: "descending",
    // });

    // console.log(res1x);
    // const connections1 = res1x.result.users;
    // if (!connections1 || connections1.length === 0) {
    //   console.log("No connections found.");
    //   return;
    // }
    // connections1.forEach((person) => {
    //   console.log(person);
    // });
  };
  const handleAuthClick = (event) => {
    gapi.auth2.getAuthInstance().signIn();
  };
  const initClient = () => {
    // gapi.client.load("client:auth2", () => {
    //console.log("loaded client");
    setIsLoadingGoogleDriveApi(true);

    gapi.client
      .init({
        apiKey: API_KEY,
        clientId: CLIENT_ID,
        discoveryDocs: DISCOVERY_DOCS,
        scope: scopes,
      })
      .then(
        function () {
          // Listen for sign-in state changes.
          gapi.auth2.getAuthInstance().isSignedIn.listen(updateSigninStatus);

          // Handle the initial sign-in state.
          updateSigninStatus(gapi.auth2.getAuthInstance().isSignedIn.get());
          // gapi.auth2
          //   .getAuthInstance()
          //   .signIn()
          //   .then(async () => {
          //     gapi.client.load("admin", "directory_v1", () => {
          //       // now we can use:
          //       // gapi.client.admin
          //       // gapi.client.directory
          //     });
          //     const res1 = await gapi.client.directory.groups.list({
          //       customer: "my_customer",
          //     });
          //     console.log(res1.result.groups);

          //     const res1x = await gapi.client.directory.users.list({
          //       customer: "my_customer",
          //       //viewType:'domain_public',
          //       //query: "orgUnitPath='/'",
          //       // query:'orgTitle=Developer',
          //       //query:'MyCustomField.CF2=parjinder',
          //       //query: "MyCustomField.CF4>1987-08-05",

          //       projection: "full",
          //       orderBy: "givenName",
          //       sortOrder: "descending",
          //     });
          //     // console.log(res1x);
          //     const connections1 = res1x.result.users;
          //     if (!connections1 || connections1.length === 0) {
          //       console.log("No connections found.");
          //       return;
          //     }
          //     connections1.forEach((person) => {
          //       console.log(person);
          //     });
          //   });
        },
        function (error) {
          console.log(error);
        }
      );
  };

  const handleClientLoad = () => {
    gapi.load("client:auth2", initClient);
  };

  return (
    <NewDocumentWrapper>
      <Row gutter={16} className="custom-row">
        <Col span={8}>
          <Spin spinning={isLoadingGoogleDriveApi} style={{ width: "100%" }}>
            <div
              onClick={() => handleClientLoad()}
              className="source-container"
            >
              <div className="icon-container">
                <div className="icon icon-success">
                  <img height="80" width="80" src={GoogleDriveImage} />
                </div>
              </div>
              <div className="content-container">
                <p className="title">Sign in with Google</p>
              </div>
            </div>
          </Spin>
        </Col>
      </Row>
    </NewDocumentWrapper>
  );
};

export default SelectSource;
